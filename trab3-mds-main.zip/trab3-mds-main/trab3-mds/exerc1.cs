﻿using System;

namespace Trabalho_3
{
    class exerc1
    {
        static void Main(string[] args) {

            //Início do exercício 1 (padrão):
            // System.Console.WriteLine("\n\nOlá! Este é o Trabalho 3 do curso Técnico de Informatica para Internet.\n\n");
            // System.Console.WriteLine("Exercício 1: Escreva um algoritmo que receba 3 notas. Calcule a média das notas e mostre na tela.");
            // Console.ReadKey();
            //---------------------------------------------------------------------------------

            // System.Console.Write("Informe a primeira nota: ");
            // int nota1 = int.Parse(Console.ReadLine());

            // System.Console.Write("\nInforme a segunda nota: ");
            // int nota2 = int.Parse(Console.ReadLine());

            // System.Console.Write("\nInforme a terceira e última nota: ");
            // int nota3 = int.Parse(Console.ReadLine());

            // int media = (nota1+nota2+nota3) / 3;
            // System.Console.WriteLine("\nA sua média de notas foi: " + media);
            //---------------------------------------------------------------------------------


            // System.Console.WriteLine("\n\n\nAté o próximo exercício!");
            // System.Console.WriteLine("----------------------------------------");
            // Console.ReadKey();

//---------------------------------------------------------------------------------
            //Chamada para os outros exercícios:
            // exerc2.Produto();
            // exerc3.Area();
            // exerc4.Desconto();
            // exerc5.Desconto2();
            // exerc6.Inversao();
            // exerc7.Faturamento();
            // exerc8.SaldoDevedor();
            // exerc9.PIZ();
            // exerc101.Maior2();
            // exerc102.Maior3();
            // exerc103.MaiorMenor3();
            // exerc104.MaiorMeioMenor3();
            // exerc105.Crescente3();
            // exerc11.PesoIdeal();
            // exerc12.Triangulo();
            // exerc13.Cadastro();
            exerc14.Entrada();
        }
    }
}