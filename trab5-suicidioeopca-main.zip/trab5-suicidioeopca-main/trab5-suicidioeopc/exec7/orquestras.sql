CREATE TABLE `exec7`.`orquestras` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `cidade` VARCHAR(45) NOT NULL,
  `país` VARCHAR(45) NOT NULL,
  `data` DATE NOT NULL,
  `sinfonia` INT NOT NULL,
  PRIMARY KEY (`id`));
