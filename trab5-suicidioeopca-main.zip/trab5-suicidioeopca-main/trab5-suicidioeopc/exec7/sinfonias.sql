CREATE TABLE `exec7`.`sinfonias` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `sinfonia` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`));
