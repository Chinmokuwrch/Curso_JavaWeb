CREATE TABLE `exec6`.`obras` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `localização` VARCHAR(45) NOT NULL,
  `tipo` VARCHAR(45) NOT NULL,
  `construtora` INT NOT NULL,
  PRIMARY KEY (`id`));
