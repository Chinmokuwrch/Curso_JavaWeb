CREATE TABLE `exec6`.`engenheiros` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `cpf` VARCHAR(45) NOT NULL,
  `crea` VARCHAR(45) NOT NULL,
  `telefone` VARCHAR(45) NOT NULL,
  `obra` INT NOT NULL,
  PRIMARY KEY (`id`));