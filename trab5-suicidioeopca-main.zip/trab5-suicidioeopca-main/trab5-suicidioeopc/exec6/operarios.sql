CREATE TABLE `exec6`.`operarios` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `CTPS` VARCHAR(8) NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  `endereço` VARCHAR(45) NOT NULL,
  `telefones` VARCHAR(45) NOT NULL,
  `obra` INT NOT NULL,
  PRIMARY KEY (`id`));
