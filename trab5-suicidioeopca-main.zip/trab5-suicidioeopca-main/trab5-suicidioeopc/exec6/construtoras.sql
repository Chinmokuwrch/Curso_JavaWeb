CREATE TABLE `exec6`.`construtoras` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `cnpj` VARCHAR(14) NOT NULL,
  `capital` DOUBLE NOT NULL,
  PRIMARY KEY (`id`));