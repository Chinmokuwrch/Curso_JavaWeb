CREATE TABLE `exec3`.`eventos` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NULL,
  `data` DATE NULL,
  `hora` TIME NULL,
  `tipo` VARCHAR(255) NULL,
  PRIMARY KEY (`id`));
