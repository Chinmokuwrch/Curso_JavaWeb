CREATE TABLE `exec5`.`categorias` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `descrição` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`));
