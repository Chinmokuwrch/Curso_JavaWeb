CREATE TABLE `exec5`.`autores` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `naciolidade` VARCHAR(45) NOT NULL,
  `livros` INT NOT NULL,
  PRIMARY KEY (`id`));
