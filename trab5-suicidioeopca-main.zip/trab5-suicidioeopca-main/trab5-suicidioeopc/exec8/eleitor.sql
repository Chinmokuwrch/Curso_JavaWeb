CREATE TABLE `exec8`.`eleitor` (
  `titulo-eleitoral` VARCHAR(12) NOT NULL,
  `RG` VARCHAR(45) NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  `endereco` VARCHAR(45) NOT NULL,
  `data-de-nascimento` DATE NOT NULL,
  `nome-da-mae` VARCHAR(45) NOT NULL);
