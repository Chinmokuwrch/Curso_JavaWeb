CREATE TABLE `exec8`.`candidato` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `foto` BLOB NOT NULL,
  `partidoPolitico` INT NOT NULL,
  PRIMARY KEY (`id`));
