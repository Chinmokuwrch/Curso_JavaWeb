CREATE TABLE `exec4`.`clientes` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `RG` VARCHAR(45) NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  `telefone` VARCHAR(45) NOT NULL,
  `endereço` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`));
