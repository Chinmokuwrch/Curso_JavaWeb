CREATE TABLE `exec4`.`produtos` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome-do-produto` VARCHAR(255) NOT NULL,
  `tipo` VARCHAR(45) NOT NULL,
  `preço` DOUBLE NOT NULL,
  PRIMARY KEY (`id`));
