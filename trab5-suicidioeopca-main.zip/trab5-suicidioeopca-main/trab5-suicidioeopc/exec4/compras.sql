CREATE TABLE `exec4`.`compras` (
  `cliente` INT NOT NULL,
  `data` DATE NOT NULL,
  `valor` DOUBLE NOT NULL,
  `produtos` INT NOT NULL);
