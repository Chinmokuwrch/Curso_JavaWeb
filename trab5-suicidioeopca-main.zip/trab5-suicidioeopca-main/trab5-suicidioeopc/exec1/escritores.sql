CREATE TABLE `exec1`.`escritores` (
  `código` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NULL,
  `e-mail` VARCHAR(45) NULL,
  `telefone` VARCHAR(45) NULL,
  `endereço` VARCHAR(45) NULL,
  PRIMARY KEY (`código`));
