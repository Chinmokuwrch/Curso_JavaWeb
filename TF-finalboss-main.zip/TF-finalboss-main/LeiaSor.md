# TF-finalboss
bom sor como o senhor disse eu poderia entregar o trabalho final ate domingo mas como eu vou ir "viajar" nao vou conseguir entao tentei fazer algo e queria explicar um pouco sobre ele, minha ideia era criar um centro de anotações para pessoas que queiram ter uma vida mais saudavel.. Podendo anotar dietas com nomes alimentos e horarios.
consegui fazer uma tela basica mostrada no console com pelo menos as funções sem erros... me desculpe pelos incomodos e um bom fim de semana para o senhor.
