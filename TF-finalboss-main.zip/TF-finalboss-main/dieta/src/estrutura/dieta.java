package estrutura;

import java.util.Scanner;

public class dieta {

	public static void main(String[] args) {
		
		String[] nome = new String[3];
		String[] alimentos = new String[3];
		String[] horarios = new String[3];
		
		for (int i = 0; i < 3; i++) {
			nome[i] = "";
			alimentos[i] = "";
			horarios[i] = "";
		}
		
		String opcao = "";
		String continuar = "";
		int posicao = 0;
		String nomeExcluir = "";
		
		
		try (Scanner entrada = new Scanner(System.in)) {
			do {
				
				System.out
				        .println("Escola a op��o: Incluir - Listar - Excluir - Sair");
				opcao = entrada.nextLine();
				
				switch (opcao) {
				case "Incluir":
					
					do {
						System.out.print("Digite o nome: ");
						nome[posicao] = entrada.nextLine();
						
						System.out.print("Digite os alimentos: ");
						alimentos[posicao] = entrada.nextLine();
						
						System.out.print("Digite os horarios: ");
						horarios[posicao] = entrada.nextLine();
						
						System.out.print("Deseja continuar o cadastramento?");
						continuar = entrada.nextLine();
						
						posicao++;
				
					} while (continuar.equals("Sim"));
					
					
					break;
					
				case "Listar":
					for (int i =0; i < 3; i++) {
						
						if(!nome[i].equals("")) {
						
						System.out.println("Nome : " + nome[i] + " " +
						               "Alimentos: " + alimentos[i] + " " + 
								        "Horarios: " + horarios[i]);
						
					    }
					}
					
					break;
					
				case "Excluir":
					System.out.println("Quem deseja excluir?");
					nomeExcluir = entrada.nextLine();
					
					for (int i = 0; i <3; i++) {
						if (nome[i].equals(nomeExcluir)) {
							nome[i] = "";
							alimentos[i] = "";
							horarios[i] = "";
						}
					}
					
					break;
					
				case "Sair":
					System.out.println("Programa Finalizado.");
					return;
					
					
				default:
						System.out.println("Op��o Inv�lida! Tente novamente");
						break;
				}
				
			} while (!opcao.equals("Sair"));
		}

	}

}
