package com.lucasvargas.agenda.controller;

import com.lucasvargas.agenda.model.Agenda;

public class App {

	public static void main(String[] args) {
		Agenda agenda = new Agenda();
		agenda.iniciarAgenda();
	}

}
